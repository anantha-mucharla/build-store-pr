import express, { Request, Response } from 'express'
import { User, UserStore } from '../models/user'
import verifyToken, {RequestCustom} from '../middleware/authen'
import jwt from 'jsonwebtoken'


const store = new UserStore()

const create =createfunc;

const index =indexfunc;

const userRoutes =userRoutesfunc;
function  userRoutesfunc(app:express.Application){
    app.post('/users', create)
    app.get('/users', verifyToken, index )
    app.get('/users/:id', verifyToken, show )
    app.post('/authenticate', authenticate)
}

async function  createfunc(_req: Request, res: Response){
    try {
        const user: User = {
            username: _req.body.username,
            firstname: _req.body.firstname,
            lastname: _req.body.lastname,
            password: _req.body.password
        }

        const newUser = await store.create(user)

        var token = jwt.sign({user: newUser}, process.env.TOKEN_SECRET!)

        res.json({'token': token})
    } catch(err) {
        res.status(400)
        res.json(err)
    }
}

async function indexfunc(_req: Request, res: Response) {
    try {
    const users = await store.index()
    res.json(users)
} catch(err) {
    res.status(400)
    res.json(err)
}
  }
  
const show =showfunc;

const authenticate =authenticatefunc;

async function showfunc (req: Request, res: Response){
    try {
        const customReq = req as RequestCustom
        const user = await store.show(req.params.id)
        res.json(user)
    } catch(err) {
        res.status(400)
        res.json(err)
    }
}

async function authenticatefunc (_req: Request, res: Response){
    try {
        const user: User = {
            username: _req.body.username,
            password: _req.body.password
        }

        const authUser = await store.authenticate(user.username, user.password)
        var token = jwt.sign({user: authUser}, process.env.TOKEN_SECRET!)
        res.json({'token': token})
    } catch(err) {
        res.status(400)
        res.json(err)
    }
}


export default userRoutes