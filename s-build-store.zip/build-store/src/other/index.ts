import express, { Request, Response } from 'express'
import bodyParser from 'body-parser'

const app: express.Application = express()
const address: string = "0.0.0.0:3000"

app.use(bodyParser.json())

app.get('/',getfunc);

function getfunc (req: Request, res: Response) {
    res.send('Hello World!, Getting Strated.')
}


//dashboard_routes(app);

app.listen(3000,listening);

function listening() {
    console.log(`starting app on: ${address}`)
}

//function dashboard_routes(app: express.Application) {
//    throw new Error('Function not implemented.')
//}

export default app;

