import supertest from 'supertest';
import Clinte from '../../database';
import app from '../../server';
import {UserStore , User} from '../../models/user';


const userStore = new UserStore();
const request = supertest(app);
let token = '';

describe('User API Endpoints',describefunc);

function  describefunc(){
	const newUser = {
		username: 'userTesting',
		firstname: 'Ahmed',
		lastname: 'Sabry',
		password: 'test123',
	}  as User ;

	beforeAll(async () => {
		const createdUser = await userStore.create(newUser);
		newUser.id = createdUser.id;
	});

	afterAll(async () => {
		const conn = await Clinte.connect();

		const sql = 'DELETE FROM users;';
		await conn.query(sql);
		conn.release();
	});

	describe('Test Authenticate methods',testauFunc);
    function  testauFunc() {
		it('should be able to authenticate to get token', async () => {
			const auth = await request
				.post('/users/login')
				.set('Content-type', 'application/json')
				.send({
					email: 'A.Sabry@info.com',
					password: 'test123',
				});
			expect(auth.status).toBe(200);
			const { id, accessToken } = auth.body.data;
			expect(id).toBe(newUser.id);

			token = accessToken;
		});

		it('FAILD TO AUTHENTICATE WITH RWONG EMAIL', async () => {
			const auth = await request
				.post('/api/users/login')
				.set('Content-type', 'application/json')
				.send({
					email: 'invalid@email.com',
					password: 'test123',
				});
			expect(auth.status).not.toBe(200);
		});
	};

	describe('==> REGISTER / ROUTE',regisFunc);
    function  regisFunc() {

			it(' RETURN STATUS(200) and NEW USER',returnfunc);

            it(' WITHOUT ADMIN OR VALID TOKen RETURN ERROR ',withoutFunc);

            it('VALIDATION RETURN ERROE WITH  INVALID INPUTS',validationfunc);

            it(' WITH EXIST EMAIL IN DB SHOULD RETURN ERORR',withexFun);

            async function  returnfunc(){
				const register = await request
					.post('/users/signup')
					.set({
						'Content-type': 'application/json',
						Authorization: 'Bearer ' + token,
						role: 'admin',
					})
					.send({
						username: 'userTesting22',
						firstname: 'Ahmed22',
						lastname: 'Sabry22',
						password: 'test12322',
					});
				const { id, username, firstname, lastname } =
					register.body.data;
				expect(register.status).toBe(200);
				expect(id).toEqual(id);
				expect(username).toEqual('userTesting22');
				expect(firstname).toEqual('Ahmed22');
				expect(lastname).toEqual('Sabry22');
			};
			

            async function  withoutFunc(){
				const register = await request
					.post('/users/signup')
					.set({
						'Content-type': 'application/json',
						Authorization: 'Bearer ' + token,
					})
					.send({
						username: 'userTesting22',
						firstname: 'Ahmed22',
						lastname: 'Sabry22',
						password: 'test12322',
					});

				expect(register.status).not.toBe(200);
			};

			
            async function  validationfunc() {
				const register = await request
					.post('/users/signup')
					.set({
						'Content-type': 'application/json',
						Authorization: 'Bearer ' + token,
					})
					.send({
						username: '',
						firstname: 'Ahmed22',
						lastname: 'Sabry22',
						password: 'test12322',
					});

				expect(register.status).not.toBe(200);
			};

            async function  withexFun() {
				const register = await request
					.post('/users/signup')
					.set({
						'Content-type': 'application/json',
						Authorization: 'Bearer ' + token,
					})
					.send({
						username: 'userTesting22',
						firstname: 'Ahmed22',
						lastname: 'Sabry22',
						password: 'test12322',
					});

				expect(register.status).not.toBe(200);
			};
	};

	
};

